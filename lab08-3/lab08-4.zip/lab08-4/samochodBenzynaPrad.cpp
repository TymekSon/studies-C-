#include "SamochodBenzynaPrad.h"
#include <iostream>

SamochodBenzynaPrad::SamochodBenzynaPrad() : ZbiornikBenzyna(0), Akumulator(0) {
    std::cout << "Utworzono samochod hybrydowy (benzyna + prad)" << std::endl;
}

SamochodBenzynaPrad::~SamochodBenzynaPrad() {
    std::cout << "Usunieto samochod hybrydowy (benzyna + prad)" << std::endl;
}

void SamochodBenzynaPrad::Uruchom() {
    SamochodBenzyna::Uruchom();
    SamochodPrad::Uruchom();
}

void SamochodBenzynaPrad::UruchomElektryczny() {
    SamochodPrad::Uruchom();
}

void SamochodBenzynaPrad::UruchomSpalinowy() {
    SamochodBenzyna::Uruchom();
}

void SamochodBenzynaPrad::Wylacz() {
    SamochodBenzyna::Wylacz();
    SamochodPrad::Wylacz();
}

void SamochodBenzynaPrad::Jedz() {
    SamochodBenzyna::Jedz();
    SamochodPrad::Jedz();
    if (Akumulator == 1) {
        Akumulator == 0;
    }
    else {
        ZbiornikBenzyna = 0;
    }
}

void SamochodBenzynaPrad::Tankuj() {
    SamochodBenzyna::Tankuj();
    SamochodPrad::Tankuj();
    ZbiornikBenzyna = 1;
    Akumulator = 1;
}