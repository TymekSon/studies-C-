#include "Samochod.h"
#include <iostream>

Samochod::Samochod() : Silnik(0) {
    std::cout << "Utworzono Samochod, Ustawiono silnik na 0" << std::endl;
}

Samochod::~Samochod() {
    std::cout << "Usunieto obiekt samochod" << std::endl;
}